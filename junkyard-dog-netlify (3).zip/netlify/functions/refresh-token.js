// Netlify serverless function — handles both:
// 1. Initial auth code → access_token + refresh_token exchange
// 2. Ongoing refresh_token → new access_token (silent, every ~55 min)
//
// Environment variables to set in Netlify dashboard:
//   GOOGLE_CLIENT_ID     — your OAuth client ID (.apps.googleusercontent.com)
//   GOOGLE_CLIENT_SECRET — your OAuth client secret

exports.handler = async function(event, context) {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const clientId     = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    return {
      statusCode: 500, headers,
      body: JSON.stringify({
        error: 'not_configured',
        message: 'Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in Netlify → Site settings → Environment variables'
      })
    };
  }

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch(e) { return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  // Build the token request params
  const params = {
    client_id:     clientId,
    client_secret: clientSecret,
  };

  if (body.refresh_token) {
    // Mode 1: silent refresh — swap refresh_token for new access_token
    params.refresh_token = body.refresh_token;
    params.grant_type    = 'refresh_token';
  } else if (body.code) {
    // Mode 2: initial exchange — swap auth code for access + refresh tokens
    params.code          = body.code;
    params.redirect_uri  = body.redirect_uri || 'urn:ietf:wg:oauth:2.0:oob';
    params.grant_type    = 'authorization_code';
  } else {
    return {
      statusCode: 400, headers,
      body: JSON.stringify({ error: 'Provide either refresh_token or code' })
    };
  }

  try {
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params)
    });

    const data = await res.json();

    if (data.error) {
      return {
        statusCode: 400, headers,
        body: JSON.stringify({ error: data.error, message: data.error_description })
      };
    }

    // Return only what the browser needs — never echo back the client_secret
    return {
      statusCode: 200, headers,
      body: JSON.stringify({
        access_token:  data.access_token,
        refresh_token: data.refresh_token || null,  // only present on first exchange
        expires_in:    data.expires_in || 3600
      })
    };

  } catch(e) {
    return {
      statusCode: 500, headers,
      body: JSON.stringify({ error: 'Token exchange failed: ' + e.message })
    };
  }
};
